# Beyaz Eşya Servisi Web Sitesi

Modern, profesyonel beyaz eşya servisi web sitesi. Tamamen yönetilebilir admin paneli ile.

## Özellikler

- ✅ Modern ve responsive tasarım (Kırmızı-Beyaz tema)
- ✅ Tam yetkili admin paneli
- ✅ Hizmet yönetimi (Çamaşır makinesi, buzdolabı tamiri vb.)
- ✅ Blog sistemi
- ✅ İletişim formu
- ✅ Teklif alma formu
- ✅ SEO dostu (Meta tags, canonical URL)
- ✅ Mobil uyumlu
- ✅ Yorum sistemi
- ✅ Galeri yönetimi

## Teknolojiler

- PHP 7.4+
- MySQL 5.7+
- Bootstrap 5
- jQuery

## Kurulum

Detaylı kurulum talimatları için `KURULUM.txt` dosyasına bakınız.

## Admin Girişi

Varsayılan admin bilgileri:
- Kullanıcı Adı: `admin`
- Şifre: `admin123`

**ÖNEMLİ:** İlk girişte şifrenizi değiştirin!

## Sayfa Yapısı

- Anasayfa
- Hakkımızda
- Hizmetlerimiz
- Blog
- SSS
- İletişim
- Teklif Al

## Destek

Herhangi bir sorunla karşılaşırsanız lütfen bizimle iletişime geçin.
